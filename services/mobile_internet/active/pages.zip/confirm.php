<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>

    <!-- Own Css -->
    <link rel="stylesheet" href="../../../css/style.css">
    <link rel="stylesheet" href="../css/style.css">
</head>
<body class="confirm">
<div class="check_page" style="text-align: center;">
    <div class="warning_img">
        <img src="../../../img/warning.png" alt="">
    </div>
    <p class="check_title">Растау</p>
    <p class="check_title_two">Енгізілген деректер дұрыс екенін тексеріңіз</p>
    <p class="check_title_three">Абонет нөмері</p>
    <p class="check_phone_number">+7777777777</p>

    <div class="button_back_and_next">
        <div class="back_button"><a href="index.php">back</a></div>
        <div class="next_button"><a href="push_money.php">next</a></div>
    </div>
</div>
<!-- Jquery -->
<script src="../../../js/jquery-3.4.1.js"></script>
<!-- Own JavaScript -->
<script src="../../../js/script.js"></script>
</body>
</html>

